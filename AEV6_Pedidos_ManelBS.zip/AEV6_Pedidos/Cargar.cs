﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AEV6_Pedidos
{
    class Cargar
    {
        public void cargarArchivo(DataGridView tabla, char caracter, string filePath)
        {
            StreamReader objReader = new StreamReader(filePath);
            string sLine = "";
            int fila = 0;
            tabla.Rows.Clear();
            tabla.AllowUserToAddRows = false;

            do
            {
                sLine = objReader.ReadLine();
                if (sLine != null)
                {
                    rellenarFila(tabla, sLine, caracter, fila);
                }

            } while (!(sLine == null));



        }
        //agraga una fila por cada linea en el bloc de notas 
        public static void rellenarFila(DataGridView tabla, string linea, char caracter, int fila)
        {
            string[] arreglo = linea.Split(caracter);
            tabla.Rows.Add(arreglo);
        }
    }
}
