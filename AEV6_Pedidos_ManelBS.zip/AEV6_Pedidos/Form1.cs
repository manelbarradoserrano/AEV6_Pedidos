﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.WebRequestMethods;

namespace AEV6_Pedidos
{
    public partial class FormPrincipal : Form
    {
        double total = 0;

        public FormPrincipal()
        {
            InitializeComponent();
        }

        private void FormPrincipal_Load(object sender, EventArgs e)
        {
            lblReloj.Text = DateTime.Now.ToString("T");
            tmrReloj.Enabled = true;
            tmrReloj.Interval = 1000;
            lblPrecioTotal.Text = "0€";
            txtNumPedido.Text = "00001";
            dateFecha.Value = DateTime.Now;
            grdProductos.AllowUserToAddRows = false;
            grdResumenPedido.AllowUserToAddRows = false;


            string mensaje = "¿Desea cargar algun archivo?";
            DialogResult r = MessageBox.Show(mensaje, "Abrir archivo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                Cargar archivo = new Cargar();
                string ruta = "";
                this.openFileDialog1.ShowDialog();

                if (!string.IsNullOrEmpty(this.openFileDialog1.FileName))
                {
                    ruta = this.openFileDialog1.FileName;
                    archivo.cargarArchivo(grdResumenPedido,'\t', ruta);
                }
            }

        }

        //Funcionamiento del reloj
        private void tmrReloj_Tick(object sender, EventArgs e)
        {
            lblReloj.Text = DateTime.Now.ToString("T");
        }

        //Registrar un pedido en el DataGrid Resumen
        private void btnRegistrarPedido_Click(object sender, EventArgs e)
        {
            
            int total_productos = 0;
            int numPedido = int.Parse(txtNumPedido.Text);
            if (txtNIF.Text == "")
            {

                MessageBox.Show("No se ha establecido ningún NIF.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            else
            {
                foreach (DataGridViewRow row in grdProductos.Rows)
                {
                    total_productos += Convert.ToInt32(row.Cells[0].Value);
                }
                grdResumenPedido.Rows.Add(txtNumPedido.Text, txtNIF.Text, dateFecha.Value, total_productos, lblPrecioTotal.Text);
                numPedido += 1;
                txtNumPedido.Text = numPedido.ToString("D5");
                //Vaciamos el DataGrid cuando registramos el pedido
                grdProductos.Rows.Clear();
                lblPrecioTotal.Text = "";
            }
        }
          

        //Seleccionar un producto en el ComboBox
        private void cmbProductos_SelectedIndexChanged(object sender, EventArgs e)
        {
            Pedido p1 = new Pedido(txtNIF.Text, txtNombre.Text,txtDireccion.Text,dateFecha.Value,cmbProductos.Text,(int)txtCantidad.Value);
            double valor = p1.DeterminarPrecio();
            txtPrecio.Text = valor.ToString()+"€";
            txtCantidad.Value = 1;
        }

        //Añadir un producto al datagrid
        private void btnAñadirProducto_Click(object sender, EventArgs e)
        {
            
            Pedido p1 = new Pedido(txtNIF.Text, txtNombre.Text, txtDireccion.Text, dateFecha.Value, cmbProductos.Text, (int)txtCantidad.Value);
            double valor = p1.DeterminarPrecio();
            if (grdProductos.Rows.Count >= 3)
            {
                MessageBox.Show("No puede añadir más de 3 productos.","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            else
            {
                if (txtCantidad.Value != 0)
                {
                    double importe = p1.CalcularImporte();
                    grdProductos.Rows.Add(txtCantidad.Value, cmbProductos.Text, txtPrecio.Text, importe + "€");
                     total += importe;
                     lblPrecioTotal.Text = total.ToString();
                    /*int total = 0;
                    string ekfe = "";
                    foreach (DataGridViewRow row in grdProductos.Rows)
                    {
                        ekfe = Convert.ToString(row.Cells[3].Value);
                        total += Convert.ToInt32(ekfe);
                    }
                    ekfe = Convert.ToString(total);
                    lblTotal.Text = ekfe;*/
                }
                else
                {
                    MessageBox.Show("No has seleccionado ningún producto.", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            
            cmbProductos.Text = "";
            txtPrecio.Text = "";
            txtCantidad.Value = 0;


        }

       /* private void grdProductos_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
           string mensaje = "Borrado de registro seleccionado. ¿Continuar?";          
          
           
            DialogResult r = MessageBox.Show(mensaje, "Eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (r== DialogResult.Yes)
            {
                
                grdProductos.Rows.RemoveAt(e.RowIndex);
               
            }
        }*/

        //Guardar el resumen de pedidos
        private void btnGuardarResumen_Click(object sender, EventArgs e)
        {
            TextWriter sw = new StreamWriter($@"Resumen.txt");
            for (int i = 0; i < grdResumenPedido.Rows.Count; i++)
            {
                
                sw.WriteLine(grdResumenPedido.Rows[i].Cells[0].Value.ToString() + "\t"
                             + grdResumenPedido.Rows[i].Cells[1].Value.ToString() + "\t"
                              + grdResumenPedido.Rows[i].Cells[2].Value.ToString() + "\t"
                               + grdResumenPedido.Rows[i].Cells[3].Value.ToString() + "\t"
                               + grdResumenPedido.Rows[i].Cells[4].Value.ToString() + "\t");
                
                
            }
            sw.Close();
            MessageBox.Show("Datos guardados con exito", "Guardar archivo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            //Vaciamos el DataGrid cuando guardamos el resumen de pedidos
            grdResumenPedido.Rows.Clear();
        }

 
        //Eliminar producto con doble click
        private void grdProductos_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            string mensage = "¿Desea borrar el producto seleccionado?";
            string caption = "error detectado";
            MessageBoxButtons botones = MessageBoxButtons.YesNo;
            DialogResult resultado;
            resultado = MessageBox.Show(mensage, caption, botones);

            if (resultado == System.Windows.Forms.DialogResult.Yes)
            {
                grdProductos.Rows.RemoveAt(e.RowIndex);
                
            }

            //Esta es una de las ultimas pruebas de arreglar el fallo de restar el importe al borrar
            //un producto, he dejado una como ejemplo de codigo que habia pensado pero en todas me da algun 
            //tipo de error, el mas comun es que no se puede convertir los valores
            /*lblPrecioTotal.Text = "";
            double precioTotal = 0;
            foreach (DataGridViewRow item in grdProductos.Rows)
            {
                precioTotal += Convert.ToDouble(item.Cells[3].Value);
            }

            lblPrecioTotal.Text = Convert.ToString(precioTotal);*/
        }
    }
    
}

















//if (SaveFileDialog )


/*string txt = saveFileDialog1.FileName;

StreamWriter textoaguardar = System.IO.File.CreateText(txt);
for (int i = 0; i < grdResumenPedido.Rows.Count - 1; i++)
{
    textoaguardar.WriteLine(grdResumenPedido.Rows[i].Cells[0].Value.ToString() + "\t"
                     + grdResumenPedido.Rows[i].Cells[1].Value.ToString() + "\t"
                      + grdResumenPedido.Rows[i].Cells[2].Value.ToString() + "\t"
                       + grdResumenPedido.Rows[i].Cells[3].Value.ToString() + "\t"
                       + grdResumenPedido.Rows[i].Cells[4].Value.ToString() + "\t");
}*/
