﻿namespace AEV6_Pedidos
{
    partial class FormPrincipal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormPrincipal));
            this.grbDatosCliente = new System.Windows.Forms.GroupBox();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.lblNombre = new System.Windows.Forms.Label();
            this.txtDireccion = new System.Windows.Forms.TextBox();
            this.lblDireccion = new System.Windows.Forms.Label();
            this.txtNIF = new System.Windows.Forms.TextBox();
            this.lblNIF = new System.Windows.Forms.Label();
            this.lblNumPedido = new System.Windows.Forms.Label();
            this.txtNumPedido = new System.Windows.Forms.TextBox();
            this.lblFechaPedido = new System.Windows.Forms.Label();
            this.grbDatosProducto = new System.Windows.Forms.GroupBox();
            this.cmbProductos = new System.Windows.Forms.ComboBox();
            this.txtCantidad = new System.Windows.Forms.NumericUpDown();
            this.lblCantidad = new System.Windows.Forms.Label();
            this.txtPrecio = new System.Windows.Forms.TextBox();
            this.lblPrecio = new System.Windows.Forms.Label();
            this.lblNombreProducto = new System.Windows.Forms.Label();
            this.lblPedidosYRecibos = new System.Windows.Forms.Label();
            this.dateFecha = new System.Windows.Forms.DateTimePicker();
            this.lblReloj = new System.Windows.Forms.Label();
            this.tmrReloj = new System.Windows.Forms.Timer(this.components);
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.grdProductos = new System.Windows.Forms.DataGridView();
            this.Cantidad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nombre_Descripicion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Precio_Unitario = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Importe = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grdResumenPedido = new System.Windows.Forms.DataGridView();
            this.Num_Pedido = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NIF_Cliente = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Fecha = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Total_Productos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Importe_Total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblProductosGrd = new System.Windows.Forms.Label();
            this.lblResumenGrd = new System.Windows.Forms.Label();
            this.btnAñadirProducto = new System.Windows.Forms.Button();
            this.btnRegistrarPedido = new System.Windows.Forms.Button();
            this.lblTextoElim = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblPrecioTotal = new System.Windows.Forms.Label();
            this.btnGuardarResumen = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.grbDatosCliente.SuspendLayout();
            this.grbDatosProducto.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtCantidad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdProductos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdResumenPedido)).BeginInit();
            this.SuspendLayout();
            // 
            // grbDatosCliente
            // 
            this.grbDatosCliente.Controls.Add(this.txtNombre);
            this.grbDatosCliente.Controls.Add(this.lblNombre);
            this.grbDatosCliente.Controls.Add(this.txtDireccion);
            this.grbDatosCliente.Controls.Add(this.lblDireccion);
            this.grbDatosCliente.Controls.Add(this.txtNIF);
            this.grbDatosCliente.Controls.Add(this.lblNIF);
            this.grbDatosCliente.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbDatosCliente.Location = new System.Drawing.Point(88, 71);
            this.grbDatosCliente.Name = "grbDatosCliente";
            this.grbDatosCliente.Size = new System.Drawing.Size(410, 117);
            this.grbDatosCliente.TabIndex = 0;
            this.grbDatosCliente.TabStop = false;
            this.grbDatosCliente.Text = "Datos de Cliente:";
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(294, 22);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(100, 20);
            this.txtNombre.TabIndex = 5;
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Location = new System.Drawing.Point(221, 25);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(54, 14);
            this.lblNombre.TabIndex = 4;
            this.lblNombre.Text = "Nombre:";
            // 
            // txtDireccion
            // 
            this.txtDireccion.Location = new System.Drawing.Point(78, 66);
            this.txtDireccion.Name = "txtDireccion";
            this.txtDireccion.Size = new System.Drawing.Size(316, 20);
            this.txtDireccion.TabIndex = 3;
            // 
            // lblDireccion
            // 
            this.lblDireccion.AutoSize = true;
            this.lblDireccion.Location = new System.Drawing.Point(11, 69);
            this.lblDireccion.Name = "lblDireccion";
            this.lblDireccion.Size = new System.Drawing.Size(61, 14);
            this.lblDireccion.TabIndex = 2;
            this.lblDireccion.Text = "Dirección:";
            // 
            // txtNIF
            // 
            this.txtNIF.Location = new System.Drawing.Point(78, 23);
            this.txtNIF.Name = "txtNIF";
            this.txtNIF.Size = new System.Drawing.Size(100, 20);
            this.txtNIF.TabIndex = 1;
            // 
            // lblNIF
            // 
            this.lblNIF.AutoSize = true;
            this.lblNIF.Location = new System.Drawing.Point(46, 26);
            this.lblNIF.Name = "lblNIF";
            this.lblNIF.Size = new System.Drawing.Size(26, 14);
            this.lblNIF.TabIndex = 0;
            this.lblNIF.Text = "NIF:";
            // 
            // lblNumPedido
            // 
            this.lblNumPedido.AutoSize = true;
            this.lblNumPedido.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumPedido.Location = new System.Drawing.Point(88, 215);
            this.lblNumPedido.Name = "lblNumPedido";
            this.lblNumPedido.Size = new System.Drawing.Size(95, 14);
            this.lblNumPedido.TabIndex = 1;
            this.lblNumPedido.Text = "Número Pedido:";
            // 
            // txtNumPedido
            // 
            this.txtNumPedido.Enabled = false;
            this.txtNumPedido.Location = new System.Drawing.Point(189, 209);
            this.txtNumPedido.Name = "txtNumPedido";
            this.txtNumPedido.Size = new System.Drawing.Size(61, 20);
            this.txtNumPedido.TabIndex = 2;
            // 
            // lblFechaPedido
            // 
            this.lblFechaPedido.AutoSize = true;
            this.lblFechaPedido.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaPedido.Location = new System.Drawing.Point(312, 215);
            this.lblFechaPedido.Name = "lblFechaPedido";
            this.lblFechaPedido.Size = new System.Drawing.Size(83, 14);
            this.lblFechaPedido.TabIndex = 3;
            this.lblFechaPedido.Text = "Fecha Pedido:";
            // 
            // grbDatosProducto
            // 
            this.grbDatosProducto.Controls.Add(this.cmbProductos);
            this.grbDatosProducto.Controls.Add(this.txtCantidad);
            this.grbDatosProducto.Controls.Add(this.lblCantidad);
            this.grbDatosProducto.Controls.Add(this.txtPrecio);
            this.grbDatosProducto.Controls.Add(this.lblPrecio);
            this.grbDatosProducto.Controls.Add(this.lblNombreProducto);
            this.grbDatosProducto.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbDatosProducto.Location = new System.Drawing.Point(88, 292);
            this.grbDatosProducto.Name = "grbDatosProducto";
            this.grbDatosProducto.Size = new System.Drawing.Size(410, 100);
            this.grbDatosProducto.TabIndex = 5;
            this.grbDatosProducto.TabStop = false;
            this.grbDatosProducto.Text = "Datos de Producto:";
            // 
            // cmbProductos
            // 
            this.cmbProductos.FormattingEnabled = true;
            this.cmbProductos.Items.AddRange(new object[] {
            "PS4Y2MANDOSDS4",
            "PS4Y1MANDOSDS4",
            "PS3",
            "MANDOPS4DS4",
            "MANDOPS3DS4"});
            this.cmbProductos.Location = new System.Drawing.Point(17, 58);
            this.cmbProductos.Name = "cmbProductos";
            this.cmbProductos.Size = new System.Drawing.Size(121, 22);
            this.cmbProductos.TabIndex = 8;
            this.cmbProductos.SelectedIndexChanged += new System.EventHandler(this.cmbProductos_SelectedIndexChanged);
            // 
            // txtCantidad
            // 
            this.txtCantidad.Location = new System.Drawing.Point(297, 60);
            this.txtCantidad.Name = "txtCantidad";
            this.txtCantidad.Size = new System.Drawing.Size(104, 20);
            this.txtCantidad.TabIndex = 7;
            // 
            // lblCantidad
            // 
            this.lblCantidad.AutoSize = true;
            this.lblCantidad.Location = new System.Drawing.Point(294, 30);
            this.lblCantidad.Name = "lblCantidad";
            this.lblCantidad.Size = new System.Drawing.Size(55, 14);
            this.lblCantidad.TabIndex = 4;
            this.lblCantidad.Text = "Cantidad";
            // 
            // txtPrecio
            // 
            this.txtPrecio.Enabled = false;
            this.txtPrecio.Location = new System.Drawing.Point(180, 60);
            this.txtPrecio.Name = "txtPrecio";
            this.txtPrecio.Size = new System.Drawing.Size(53, 20);
            this.txtPrecio.TabIndex = 3;
            // 
            // lblPrecio
            // 
            this.lblPrecio.AutoSize = true;
            this.lblPrecio.Location = new System.Drawing.Point(177, 30);
            this.lblPrecio.Name = "lblPrecio";
            this.lblPrecio.Size = new System.Drawing.Size(42, 14);
            this.lblPrecio.TabIndex = 2;
            this.lblPrecio.Text = "Precio";
            // 
            // lblNombreProducto
            // 
            this.lblNombreProducto.AutoSize = true;
            this.lblNombreProducto.Location = new System.Drawing.Point(14, 30);
            this.lblNombreProducto.Name = "lblNombreProducto";
            this.lblNombreProducto.Size = new System.Drawing.Size(119, 14);
            this.lblNombreProducto.TabIndex = 0;
            this.lblNombreProducto.Text = "Nombre/Descripción";
            // 
            // lblPedidosYRecibos
            // 
            this.lblPedidosYRecibos.AutoSize = true;
            this.lblPedidosYRecibos.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblPedidosYRecibos.Font = new System.Drawing.Font("Arial Rounded MT Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPedidosYRecibos.Location = new System.Drawing.Point(610, 34);
            this.lblPedidosYRecibos.Name = "lblPedidosYRecibos";
            this.lblPedidosYRecibos.Size = new System.Drawing.Size(141, 17);
            this.lblPedidosYRecibos.TabIndex = 6;
            this.lblPedidosYRecibos.Text = "Pedidos y Recibos";
            // 
            // dateFecha
            // 
            this.dateFecha.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateFecha.Location = new System.Drawing.Point(401, 209);
            this.dateFecha.Name = "dateFecha";
            this.dateFecha.Size = new System.Drawing.Size(97, 20);
            this.dateFecha.TabIndex = 7;
            // 
            // lblReloj
            // 
            this.lblReloj.AutoSize = true;
            this.lblReloj.Font = new System.Drawing.Font("Arial Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReloj.Location = new System.Drawing.Point(982, 29);
            this.lblReloj.Name = "lblReloj";
            this.lblReloj.Size = new System.Drawing.Size(52, 22);
            this.lblReloj.TabIndex = 8;
            this.lblReloj.Text = "Reloj";
            // 
            // tmrReloj
            // 
            this.tmrReloj.Tick += new System.EventHandler(this.tmrReloj_Tick);
            // 
            // picLogo
            // 
            this.picLogo.Image = ((System.Drawing.Image)(resources.GetObject("picLogo.Image")));
            this.picLogo.Location = new System.Drawing.Point(754, 71);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(226, 225);
            this.picLogo.TabIndex = 9;
            this.picLogo.TabStop = false;
            // 
            // grdProductos
            // 
            this.grdProductos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdProductos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Cantidad,
            this.Nombre_Descripicion,
            this.Precio_Unitario,
            this.Importe});
            this.grdProductos.Location = new System.Drawing.Point(9, 495);
            this.grdProductos.Name = "grdProductos";
            this.grdProductos.Size = new System.Drawing.Size(503, 150);
            this.grdProductos.TabIndex = 10;
            this.grdProductos.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.grdProductos_CellMouseDoubleClick);
            // 
            // Cantidad
            // 
            this.Cantidad.HeaderText = "Cantidad";
            this.Cantidad.Name = "Cantidad";
            this.Cantidad.ReadOnly = true;
            this.Cantidad.Width = 80;
            // 
            // Nombre_Descripicion
            // 
            this.Nombre_Descripicion.HeaderText = "Nombre/Descripción";
            this.Nombre_Descripicion.Name = "Nombre_Descripicion";
            this.Nombre_Descripicion.ReadOnly = true;
            this.Nombre_Descripicion.Width = 200;
            // 
            // Precio_Unitario
            // 
            this.Precio_Unitario.HeaderText = "Precio Unitario";
            this.Precio_Unitario.Name = "Precio_Unitario";
            this.Precio_Unitario.ReadOnly = true;
            // 
            // Importe
            // 
            this.Importe.HeaderText = "Importe";
            this.Importe.Name = "Importe";
            this.Importe.ReadOnly = true;
            this.Importe.Width = 80;
            // 
            // grdResumenPedido
            // 
            this.grdResumenPedido.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdResumenPedido.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Num_Pedido,
            this.NIF_Cliente,
            this.Fecha,
            this.Total_Productos,
            this.Importe_Total});
            this.grdResumenPedido.Location = new System.Drawing.Point(581, 495);
            this.grdResumenPedido.Name = "grdResumenPedido";
            this.grdResumenPedido.Size = new System.Drawing.Size(543, 150);
            this.grdResumenPedido.TabIndex = 11;
            // 
            // Num_Pedido
            // 
            this.Num_Pedido.HeaderText = "NºPedido";
            this.Num_Pedido.Name = "Num_Pedido";
            this.Num_Pedido.ReadOnly = true;
            // 
            // NIF_Cliente
            // 
            this.NIF_Cliente.HeaderText = "NIF Cliente";
            this.NIF_Cliente.Name = "NIF_Cliente";
            this.NIF_Cliente.ReadOnly = true;
            // 
            // Fecha
            // 
            this.Fecha.HeaderText = "Fecha";
            this.Fecha.Name = "Fecha";
            this.Fecha.ReadOnly = true;
            // 
            // Total_Productos
            // 
            this.Total_Productos.HeaderText = "Total Productos";
            this.Total_Productos.Name = "Total_Productos";
            this.Total_Productos.ReadOnly = true;
            // 
            // Importe_Total
            // 
            this.Importe_Total.HeaderText = "Importe Total";
            this.Importe_Total.Name = "Importe_Total";
            this.Importe_Total.ReadOnly = true;
            // 
            // lblProductosGrd
            // 
            this.lblProductosGrd.AutoSize = true;
            this.lblProductosGrd.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblProductosGrd.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductosGrd.Location = new System.Drawing.Point(9, 473);
            this.lblProductosGrd.Name = "lblProductosGrd";
            this.lblProductosGrd.Size = new System.Drawing.Size(149, 19);
            this.lblProductosGrd.TabIndex = 12;
            this.lblProductosGrd.Text = "Productos del Pedido";
            // 
            // lblResumenGrd
            // 
            this.lblResumenGrd.AutoSize = true;
            this.lblResumenGrd.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblResumenGrd.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResumenGrd.Location = new System.Drawing.Point(581, 474);
            this.lblResumenGrd.Name = "lblResumenGrd";
            this.lblResumenGrd.Size = new System.Drawing.Size(151, 19);
            this.lblResumenGrd.TabIndex = 13;
            this.lblResumenGrd.Text = "Resumen de Pedidos";
            // 
            // btnAñadirProducto
            // 
            this.btnAñadirProducto.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAñadirProducto.Location = new System.Drawing.Point(329, 456);
            this.btnAñadirProducto.Name = "btnAñadirProducto";
            this.btnAñadirProducto.Size = new System.Drawing.Size(183, 33);
            this.btnAñadirProducto.TabIndex = 14;
            this.btnAñadirProducto.Text = "Añadir Producto";
            this.btnAñadirProducto.UseVisualStyleBackColor = true;
            this.btnAñadirProducto.Click += new System.EventHandler(this.btnAñadirProducto_Click);
            // 
            // btnRegistrarPedido
            // 
            this.btnRegistrarPedido.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistrarPedido.Location = new System.Drawing.Point(959, 459);
            this.btnRegistrarPedido.Name = "btnRegistrarPedido";
            this.btnRegistrarPedido.Size = new System.Drawing.Size(165, 33);
            this.btnRegistrarPedido.TabIndex = 15;
            this.btnRegistrarPedido.Text = "Registrar Pedido";
            this.btnRegistrarPedido.UseVisualStyleBackColor = true;
            this.btnRegistrarPedido.Click += new System.EventHandler(this.btnRegistrarPedido_Click);
            // 
            // lblTextoElim
            // 
            this.lblTextoElim.AutoSize = true;
            this.lblTextoElim.Location = new System.Drawing.Point(6, 648);
            this.lblTextoElim.Name = "lblTextoElim";
            this.lblTextoElim.Size = new System.Drawing.Size(292, 13);
            this.lblTextoElim.TabIndex = 16;
            this.lblTextoElim.Text = "*Realiza doble click sobre la línea para eliminar un producto.";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(410, 657);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(47, 18);
            this.lblTotal.TabIndex = 17;
            this.lblTotal.Text = "Total:";
            // 
            // lblPrecioTotal
            // 
            this.lblPrecioTotal.AutoSize = true;
            this.lblPrecioTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecioTotal.Location = new System.Drawing.Point(463, 656);
            this.lblPrecioTotal.Name = "lblPrecioTotal";
            this.lblPrecioTotal.Size = new System.Drawing.Size(46, 18);
            this.lblPrecioTotal.TabIndex = 18;
            this.lblPrecioTotal.Text = "euros";
            // 
            // btnGuardarResumen
            // 
            this.btnGuardarResumen.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardarResumen.Location = new System.Drawing.Point(918, 652);
            this.btnGuardarResumen.Name = "btnGuardarResumen";
            this.btnGuardarResumen.Size = new System.Drawing.Size(206, 34);
            this.btnGuardarResumen.TabIndex = 19;
            this.btnGuardarResumen.Text = "Guardar Resúmen de Pedidos";
            this.btnGuardarResumen.UseVisualStyleBackColor = true;
            this.btnGuardarResumen.Click += new System.EventHandler(this.btnGuardarResumen_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // FormPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(1153, 729);
            this.Controls.Add(this.btnGuardarResumen);
            this.Controls.Add(this.lblPrecioTotal);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.lblTextoElim);
            this.Controls.Add(this.btnRegistrarPedido);
            this.Controls.Add(this.btnAñadirProducto);
            this.Controls.Add(this.lblResumenGrd);
            this.Controls.Add(this.lblProductosGrd);
            this.Controls.Add(this.grdResumenPedido);
            this.Controls.Add(this.grdProductos);
            this.Controls.Add(this.picLogo);
            this.Controls.Add(this.lblReloj);
            this.Controls.Add(this.dateFecha);
            this.Controls.Add(this.lblPedidosYRecibos);
            this.Controls.Add(this.grbDatosProducto);
            this.Controls.Add(this.lblFechaPedido);
            this.Controls.Add(this.txtNumPedido);
            this.Controls.Add(this.lblNumPedido);
            this.Controls.Add(this.grbDatosCliente);
            this.Name = "FormPrincipal";
            this.Text = "Gestión de Pedidos";
            this.Load += new System.EventHandler(this.FormPrincipal_Load);
            this.grbDatosCliente.ResumeLayout(false);
            this.grbDatosCliente.PerformLayout();
            this.grbDatosProducto.ResumeLayout(false);
            this.grbDatosProducto.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtCantidad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdProductos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdResumenPedido)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grbDatosCliente;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.TextBox txtDireccion;
        private System.Windows.Forms.Label lblDireccion;
        private System.Windows.Forms.TextBox txtNIF;
        private System.Windows.Forms.Label lblNIF;
        private System.Windows.Forms.Label lblNumPedido;
        private System.Windows.Forms.TextBox txtNumPedido;
        private System.Windows.Forms.Label lblFechaPedido;
        private System.Windows.Forms.GroupBox grbDatosProducto;
        private System.Windows.Forms.Label lblNombreProducto;
        private System.Windows.Forms.NumericUpDown txtCantidad;
        private System.Windows.Forms.Label lblCantidad;
        private System.Windows.Forms.TextBox txtPrecio;
        private System.Windows.Forms.Label lblPrecio;
        private System.Windows.Forms.Label lblPedidosYRecibos;
        private System.Windows.Forms.DateTimePicker dateFecha;
        private System.Windows.Forms.Label lblReloj;
        private System.Windows.Forms.Timer tmrReloj;
        private System.Windows.Forms.ComboBox cmbProductos;
        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.DataGridView grdProductos;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cantidad;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nombre_Descripicion;
        private System.Windows.Forms.DataGridViewTextBoxColumn Precio_Unitario;
        private System.Windows.Forms.DataGridViewTextBoxColumn Importe;
        private System.Windows.Forms.DataGridView grdResumenPedido;
        private System.Windows.Forms.DataGridViewTextBoxColumn Num_Pedido;
        private System.Windows.Forms.DataGridViewTextBoxColumn NIF_Cliente;
        private System.Windows.Forms.DataGridViewTextBoxColumn Fecha;
        private System.Windows.Forms.DataGridViewTextBoxColumn Total_Productos;
        private System.Windows.Forms.DataGridViewTextBoxColumn Importe_Total;
        private System.Windows.Forms.Label lblProductosGrd;
        private System.Windows.Forms.Label lblResumenGrd;
        private System.Windows.Forms.Button btnAñadirProducto;
        private System.Windows.Forms.Button btnRegistrarPedido;
        private System.Windows.Forms.Label lblTextoElim;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblPrecioTotal;
        private System.Windows.Forms.Button btnGuardarResumen;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}

