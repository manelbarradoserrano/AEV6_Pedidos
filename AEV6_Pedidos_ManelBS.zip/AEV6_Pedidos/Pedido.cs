﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AEV6_Pedidos
{
    class Pedido
    {
        private string NIF;
        private string nombre;
        private string direccion;
        private DateTime fecha;
        private string descripcion;
        private int cantidad;
        private double precio;
        
        public Pedido(string nif,string nom, string direc, DateTime fecha, string descrip,int cant)
        {
            NIF = nif;
            nombre = nom;
            direccion = direc;
            this.fecha = fecha;
            descripcion = descrip;
            cantidad = cant;
        }

        public double DeterminarPrecio()
        {
            
            if (descripcion == "PS4Y2MANDOSDS4")
            {
                precio = 2000;               
            }
            else if (descripcion=="PS4Y1MANDOSDS4")
            {
                precio = 1800;
            }
            else if (descripcion == "PS3")
            {
                precio = 1350;
            }
            else if (descripcion == "MANDOPS4DS4")
            {
                precio = 250;
            }
            else if (descripcion == "MANDOPS3DS4")
            {
                precio = 175;
            }
            return precio;
        }

        public double CalcularImporte()
        {
            double importe = 0;
            if (cantidad != 0)
            {
                importe = precio * cantidad;
            }           
            return importe;
        }
           
      
    }
}
                    
                    


                
                    

                
                    


                
                    


               
                   
